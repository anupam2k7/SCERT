﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Drawing;
using SautinSoft;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String mycon = "Data Source=ANUPAM\\ANUPAMSQL;Initial Catalog=CandidateInfo;Integrated Security=True";
        SqlConnection con = new SqlConnection(mycon);
        con.Open();

        String query = "select * from Proforma where RegNo = (select max(RegNo) from Proforma)";

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = query;
        cmd.Connection = con;
        cmd.ExecuteNonQuery();

        SqlDataReader reader = cmd.ExecuteReader();

        reader.Read();
        Label1.Text = reader["RegNo"].ToString();
        Label2.Text = reader["Name"].ToString();
        Label37.Text = reader["Father"].ToString();
        Label3.Text = reader["DOB"].ToString();
        Label38.Text = reader["email"].ToString();
        Label4.Text = reader["Sex"].ToString();
        Label5.Text = reader["Nationality"].ToString();
        Label6.Text = reader["Category"].ToString();
        Label7.Text = reader["DOJ"].ToString();
        Label8.Text = reader["PrPost"].ToString();
        Label9.Text = reader["Post"].ToString();
        Label10.Text = reader["Experience"].ToString();
        Label11.Text = reader["XSub"].ToString();
        Label12.Text = reader["XBoard"].ToString();
        Label13.Text = reader["XMarks"].ToString();
        Label14.Text = reader["XDiv"].ToString();
        Label15.Text = reader["XIISub"].ToString();
        Label16.Text = reader["XIIBoard"].ToString();
        Label17.Text = reader["XIIMarks"].ToString();
        Label18.Text = reader["XIIDiv"].ToString();
        Label19.Text = reader["GSub"].ToString();
        Label20.Text = reader["GBoard"].ToString();
        Label21.Text = reader["GMarks"].ToString();
        Label22.Text = reader["GDiv"].ToString();
        Label23.Text = reader["PGSub"].ToString();
        Label24.Text = reader["PGBoard"].ToString();
        Label25.Text = reader["PGMarks"].ToString();
        Label26.Text = reader["PGDiv"].ToString();
        Label27.Text = reader["BSub"].ToString();
        Label28.Text = reader["BBoard"].ToString();
        Label29.Text = reader["BMarks"].ToString();
        Label30.Text = reader["BDiv"].ToString();
        Label31.Text = reader["MSub"].ToString();
        Label32.Text = reader["MBoard"].ToString();
        Label33.Text = reader["MMarks"].ToString();
        Label34.Text = reader["MDiv"].ToString();
        Label39.Text = reader["OSub"].ToString();
        Label40.Text = reader["OBoard"].ToString();
        Label41.Text = reader["OMarks"].ToString();
        Label42.Text = reader["ODiv"].ToString();
        Label35.Text = reader["Address"].ToString();
        Label36.Text = reader["CDate"].ToString();
        reader.Close();

        con.Close();











        string folderName = Label1.Text;
        Image1.ImageUrl = @"\Data\" + "\\" + folderName + "\\" + folderName + " Photo.jpg";
        Image2.ImageUrl = @"\Data\" + "\\" + folderName + "\\" + folderName + " Sign.jpg";

       
    }

}