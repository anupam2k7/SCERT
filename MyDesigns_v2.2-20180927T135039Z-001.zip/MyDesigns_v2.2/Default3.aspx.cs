﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Drawing;
using System.Security.Cryptography.X509Certificates;
using SautinSoft;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        string id = btn.CommandArgument.ToString();


            String mycon = "Data Source=ANUPAM\\ANUPAMSQL;Initial Catalog=CandidateInfo;Integrated Security=True";
            SqlConnection con1 = new SqlConnection(mycon);
            con1.Open();
            String query1 = "select PDF from Proforma where RegNo = ('" + id + "')";
            SqlCommand cmd1 = new SqlCommand();
            cmd1.CommandText = query1;
            cmd1.Connection = con1;
            cmd1.ExecuteNonQuery();
            SqlDataReader reader = cmd1.ExecuteReader();
            reader.Read();
            DownloadContent(reader["PDF"].ToString());
            con1.Close();
            
      
    }

    protected void btnDownload_Click1(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        string id = btn.CommandArgument.ToString();


        String mycon = "Data Source=ANUPAM\\ANUPAMSQL;Initial Catalog=CandidateInfo;Integrated Security=True";
        SqlConnection con1 = new SqlConnection(mycon);
        con1.Open();
        String query1 = "select Photo from Proforma where RegNo = ('" + id + "')";
        SqlCommand cmd1 = new SqlCommand();
        cmd1.CommandText = query1;
        cmd1.Connection = con1;
        cmd1.ExecuteNonQuery();
        SqlDataReader reader = cmd1.ExecuteReader();
        reader.Read();
        DownloadContent(reader["Photo"].ToString());
        con1.Close();


    }

    protected void btnDownload_Click2(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        string id = btn.CommandArgument.ToString();


        String mycon = "Data Source=ANUPAM\\ANUPAMSQL;Initial Catalog=CandidateInfo;Integrated Security=True";
        SqlConnection con1 = new SqlConnection(mycon);
        con1.Open();
        String query1 = "select Sign from Proforma where RegNo = ('" + id + "')";
        SqlCommand cmd1 = new SqlCommand();
        cmd1.CommandText = query1;
        cmd1.Connection = con1;
        cmd1.ExecuteNonQuery();
        SqlDataReader reader = cmd1.ExecuteReader();
        reader.Read();
        DownloadContent(reader["Sign"].ToString());
        con1.Close();


    }

    protected void btnDownload_Click3(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        string id = btn.CommandArgument.ToString();


        String mycon = "Data Source=ANUPAM\\ANUPAMSQL;Initial Catalog=CandidateInfo;Integrated Security=True";
        SqlConnection con1 = new SqlConnection(mycon);
        con1.Open();
        String query1 = "select Rec from Proforma where RegNo = ('" + id + "')";
        SqlCommand cmd1 = new SqlCommand();
        cmd1.CommandText = query1;
        cmd1.Connection = con1;
        cmd1.ExecuteNonQuery();
        SqlDataReader reader = cmd1.ExecuteReader();
        reader.Read();
        DownloadContent(reader["Rec"].ToString());
        con1.Close();


    }


    public void DownloadContent(string URL)
    {
        WebClient req = new WebClient();
        HttpResponse response = HttpContext.Current.Response;
        response.Clear();
        response.ClearContent();
        response.ClearHeaders();
        response.Buffer = true;
        string filename = Path.GetFileName(URL);
        response.AddHeader("Content-Disposition", "attachment;filename=\"" + filename + "\"");
        byte[] data = req.DownloadData(URL);
        response.BinaryWrite(data);
        response.End();
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
