﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration; 
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Net.Sockets;
using System.Drawing;
using System.Security.Cryptography.X509Certificates;
using SautinSoft;
using System.Runtime.InteropServices;





public partial class _Default : System.Web.UI.Page
{
       //Global code for Mime Type file validation
       [DllImport(@"urlmon.dll", CharSet = CharSet.Auto)]
       private extern static System.UInt32 FindMimeFromData(System.UInt32 pBC,
       [MarshalAs(UnmanagedType.LPStr)] System.String pwzUrl,
       [MarshalAs(UnmanagedType.LPArray)] byte[] pBuffer,
       System.UInt32 cbSize, [MarshalAs(UnmanagedType.LPStr)] System.String pwzMimeProposed,
       System.UInt32 dwMimeFlags,
       out System.UInt32 ppwzMimeOut,
       System.UInt32 dwReserverd);



    public void Perform()
    {

        //Insert values to database
        String mycon = "Data Source=ANUPAM\\ANUPAMSQL;Initial Catalog=CandidateInfo;Integrated Security=True";
        SqlConnection con = new SqlConnection(mycon);
        con.Open();
        String query = "insert into Proforma(Post,Name,Father,email,DOB,Age,Sex,Nationality,Category,DOJ,PrPost,Experience,XSub,XBoard,XMarks,XDiv,XIISub,XIIBoard,XIIMarks,XIIDiv,GSub,GBoard,GMarks,GDiv,PGSub,PGBoard,PGMarks,PGDiv,BSub,BBoard,BMarks,Bdiv,MSub,MBoard,MMarks,Mdiv,OSub,OBoard,OMarks,ODiv,Address,CDate) values('" + DropDownList2.Text + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox36.Text + "','" + TextBox63.Text + "','" + TextBox64.Text + "','" + DropDownList3.Text + "','" + DropDownList1.Text + "','" + DropDownList4.Text + "','" + TextBox37.Text + "','" + TextBox65.Text + "','" + TextBox3.Text + "','" + TextBox38.Text + "','" + TextBox39.Text + "','" + TextBox40.Text + "','" + DropDownList5.Text + "','" + TextBox42.Text + "','" + TextBox43.Text + "','" + TextBox44.Text + "','" + DropDownList6.Text + "','" + TextBox46.Text + "','" + TextBox47.Text + "','" + TextBox48.Text + "','" + DropDownList7.Text + "','" + TextBox50.Text + "','" + TextBox51.Text + "','" + TextBox52.Text + "','" + DropDownList8.Text + "','" + TextBox54.Text + "','" + TextBox55.Text + "','" + TextBox56.Text + "','" + DropDownList9.Text + "','" + TextBox58.Text + "','" + TextBox59.Text + "','" + TextBox60.Text + "','" + DropDownList10.Text + "','" + TextBox66.Text + "','" + TextBox67.Text + "','" + TextBox68.Text + "','" + DropDownList11.Text + "','" + TextBox62.Text + "',GETDATE())";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = query;
        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        con.Close();

        //Retrieve Registration Number from Database
        SqlConnection con1 = new SqlConnection(mycon);
        con1.Open();
        String query1 = "select * from Proforma where RegNo = (select max(RegNo) from Proforma)";
        SqlCommand cmd1 = new SqlCommand();
        cmd1.CommandText = query1;
        cmd1.Connection = con1;
        cmd1.ExecuteNonQuery();
        SqlDataReader reader = cmd1.ExecuteReader();
        reader.Read();
        Label1.Text = reader["RegNo"].ToString();
        reader.Close();
        con1.Close();

        // Create directory as per Registration Number and save Photo, Sign and Recommendation
        string folderName = Label1.Text;
        string folderPath = Server.MapPath("~/Data/" + folderName);

        if (!Directory.Exists(folderPath))
        {
            //If Directory (Folder) does not exists Create it.
            Directory.CreateDirectory(folderPath);
        }

        //Save the File to the Directory (Folder).
        FileUpload1.SaveAs(folderPath + "\\" + folderName + " Photo.jpg");
        //Save the File to the Directory (Folder).
        FileUpload2.SaveAs(folderPath + "\\" + folderName + " Sign.jpg");
        //Save the File to the Directory (Folder).
        FileUpload3.SaveAs(folderPath + "\\" + folderName + " Recommendation.pdf");

        //String fPath = Server.MapPath(@"http://localhost:52361/Data/" + folderName);





        //Auto-Triggering of email to candidate
        try
        {
            SmtpClient client = new SmtpClient();
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.Credentials = new NetworkCredential("scertarun@gmail.com", "scert@2018");
            MailMessage msgobj = new MailMessage();
            msgobj.To.Add(new MailAddress(TextBox36.Text));
            msgobj.From = new MailAddress("scertarun@gmail.com");
            msgobj.Subject = "SCERT Arunachal Pradesh Form Submission";
            msgobj.Body = "Your Form has been successfully submitted. Your Registration Number is: " + folderName;
            // Attachment data = new Attachment(file, "example.pdf", "application/pdf");

            // msgobj.Attachments.Add(data);
            client.Send(msgobj);
            //Response.Write("able");
        }

        catch
        {
            Response.Write("Unable");
        }



        //Auto Saving of PDF on Server end
        SautinSoft.PdfVision v = new SautinSoft.PdfVision();
        v.PageStyle.PageSize.Auto();
        SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry();
        FileInfo pdfFile = new FileInfo(folderPath + "\\" + folderName + " info.pdf");

        int ret = v.ConvertHtmlFileToPDFFile(@"http://localhost:52361/Default2.aspx", pdfFile.FullName);


       //Calling IP Tracking function.
        Label13.Text = LocalIPAddress();

        //Inserting folder paths of Photo, Signature, Info and Recommendation into database table
        SqlConnection con2 = new SqlConnection(mycon);
        con2.Open();
        String pdf = " info.pdf";
        String pic = " Photo.jpg";
        String sig = " Sign.jpg";
        String rec = " Recommendation.pdf";
        String query2 = "update Proforma set PDF = ('" + folderPath + "\\" + folderName + pdf + "'), Photo = ('" + folderPath + "\\" + folderName + pic + "'), Sign = ('" + folderPath + "\\" + folderName + sig + "'), Rec = ('" + folderPath + "\\" + folderName + rec + "'), IP = ('" + Label13.Text + "') where RegNo = (select max(RegNo) from Proforma)";
        SqlCommand cmd2 = new SqlCommand();
        cmd2.CommandText = query2;
        cmd2.Connection = con2;
        cmd2.ExecuteNonQuery();
        con2.Close();


        

        // Final Submission Message
        Response.Write("<script language='javascript'>window.alert('Your Data has been successfully submitted');window.location='Default2.aspx';</script>");





    }

    //IP Tracking function
    public string LocalIPAddress()
    {
        IPHostEntry host;
        string localIP = "";
        host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (IPAddress ip in host.AddressList)
        {
            if (ip.AddressFamily == AddressFamily.InterNetwork)
            {
                localIP = ip.ToString();
                break;
            }
        }
        return localIP;
    }

    //Submit Button event
    protected void Button3_Click(object sender, EventArgs e)
    {
        //Captcha Validation
        captcha2.ValidateCaptcha(TextBox69.Text.Trim());
        if (captcha2.UserValidated)
        {
            Label16.Text = ""; TextBox69.Text = "";
            string errors = "";
            //calling of validation functions
            errors += CheckPost();
            errors += CheckName();
            errors += CheckFName();
            errors += CheckEmail();
            errors += CheckDob();
            errors += CheckAge();
            errors += CheckSex();
            errors += CheckCategory();
            errors += CheckPrPost();
            errors += CheckDoe();
            errors += CheckXss();
            errors += CheckXbu();
            errors += CheckXmks();
            errors += CheckXdiv();
            errors += CheckXIIss();
            errors += CheckXIIbu();
            errors += CheckXIImks();
            errors += CheckXIIdiv();
            errors += CheckGss();
            errors += CheckGbu();
            errors += CheckGmks();
            errors += CheckGdiv();
            errors += CheckPGss();
            errors += CheckPGbu();
            errors += CheckPGmks();
            errors += CheckPGdiv();
            errors += CheckBss();
            errors += CheckBbu();
            errors += CheckBmks();
            errors += CheckMss();
            errors += CheckMbu();
            errors += CheckMmks();
            errors += CheckOss();
            errors += CheckObu();
            errors += CheckOmks();
            errors += CheckAoc();
            errors += CheckPhoto();
            errors += CheckSign();
            errors += CheckRec();


            if (errors != "")
                Response.Write("<script>alert('" + errors.ToString() + "');</script>");
            //return false;
            else Perform();

        }
        else
        {
            Response.Write("<script>alert('Enter Correct Captcha Text');</script>");
            Label16.Text = "Enter Correct Captcha Text";
        }
}


  //Validation Functions.

    public string CheckPost()
    {
        string TP = DropDownList2.SelectedValue;
        if (TP == "")
        {
            Label2.Text = "Please enter the Post for which you are applying.";
            return "Please enter the Post for which you are applying.\\n";
            //Label2.Text = "Please enter the Post for which you are applying.";
            //return false;
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TP, @"^[a-zA-Z\s]+$"))
        {
            Label2.Text = "";
            return "";
        }
        else
        {
            Label2.Text = "Please enter only alphabets for your Post Applied.";
            return "Please enter only alphabets for your Post Applied.\\n";
        }
    }

    public string CheckName()
    {
        string TN = TextBox1.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            Label3.Text = "Please enter your Name.";
            return "Please enter your Name.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            Label3.Text = "";
            return "";
        }
        else
        {
            Label3.Text = "Please enter only alphabets for your Name.";
            return "Please enter only alphabets for your Name.\\n";
            }
    }


    public string CheckFName()
    {
        string TN = TextBox2.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            Label4.Text = "Please enter your Fathers Name.";
            return "Please enter your Fathers Name.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            Label4.Text = "";
            return "";
        }
        else
        {
            Label4.Text = "Please enter only alphabets for your Fathers Name.";
            return "Please enter only alphabets for your Fathers Name.\\n";
        }
    }


    public string CheckEmail()
    {
        string TN = TextBox36.Text.ToString();

        var exp = "\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";
        if (TN == "")
        {
            Label5.Text = "Please enter your eMail ID.";
            return "Please enter your eMail ID.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, exp))
        {
            Label5.Text = "";
            return "";
        }
        else
        {
            Label5.Text = "Please enter a valid eMail ID.";
            return "Please enter a valid eMail ID.\\n";
        }
    }

    public string CheckDob()
    {
        string TN = TextBox63.Text.ToString();

        if (TN == "")
        {
            Label6.Text = "Please enter your Date of Birth.";
            return "Please enter your Date of Birth.\\n";
        }
        else
        {
            Label6.Text = "";
            return "";
        }
    }

    public string CheckAge()
    {
        string TN = TextBox64.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            Label17.Text = "";
            return "";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z0-9.,\s]+$"))
        {
            Label17.Text = "";
            return "";
        }
        else
        {
            Label17.Text = "Please enter only alphabets and numbers for your Age.";
            return "Please enter only alphabets and numbers for your Age.\\n";
        }
    }

    public string CheckSex()
    {
        string TN = DropDownList3.SelectedValue;

        if (TN == "")
        {
            Label7.Text = "Please enter your Sex.";
            return "Please enter your Sex.\\n";
        }
        else
        {
            Label7.Text = "";
            return "";
        }
    }

    public string CheckCategory()
    {
        string TN = DropDownList4.SelectedValue;

        if (TN == "")
        {
            Label8.Text = "Please enter whether you belong to General or APST.";
            return "Please enter whether you belong to General or APST.\\n";
        }
        else
        {
            Label8.Text = "";
            return "";
        }
    }

    public string CheckPrPost()
    {
        string TN = TextBox65.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            Label14.Text = "";
            return "";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            Label14.Text = "";
            return "";
        }
        else
        {
            Label14.Text = "Please enter only alphabets for your Present Post.";
            return "Please enter only alphabets for your Present Post.\\n";
        }
    }

    public string CheckDoe()
    {
        string TN = TextBox3.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            Label15.Text = "";
            return "";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z0-9.,\s-]+$"))
        {
            Label15.Text = "";
            return "";
        }
        else
        {
            Label15.Text = "Only alphabets, numbers and .,- are allowed for your Experience.";
            return "Only alphabets, numbers and .,- are allowed for your Experience.\\n";
        }
    }

    public string CheckXss()
    {
        string TN = TextBox38.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            TextBox38.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter your Class X Subject Studied.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox38.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox38.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for Class X Subject Studied.\\n";
        }
    }

    public string CheckXbu()
    {
        string TN = TextBox39.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            TextBox39.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter your Class X Board/University.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox39.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox39.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for Class X Board/University.\\n";
        }
    }


    public string CheckXmks()
    {
        string TN = TextBox40.Text.ToString();

        var exp = "[+]?([0-9]*[.])?[0-9]+";
        if (TN == "")
        {
            TextBox40.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter your Class X marks in Percentage.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, exp))
        {
            TextBox40.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox40.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only numbers for Class X marks in Percentage.\\n";
        }
    }

    public string CheckXdiv()
    {
        string TP = DropDownList5.SelectedValue;
        if (TP == "")
        {
            DropDownList5.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter Class X Division.\\n";
            
        }
        else
        {
            DropDownList5.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
    }


    public string CheckXIIss()
    {
        string TN = TextBox42.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            TextBox42.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter your Class XII Subject Studied.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox42.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox42.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for Class XII Subject Studied.\\n";
        }
    }

    public string CheckXIIbu()
    {
        string TN = TextBox43.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            TextBox43.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter your Class XII Board/University.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox43.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox43.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for Class XII Board/University.\\n";
        }
    }


    public string CheckXIImks()
    {
        string TN = TextBox44.Text.ToString();

        var exp = "[+]?([0-9]*[.])?[0-9]+";
        if (TN == "")
        {
            TextBox44.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter your Class XII marks in Percentage.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, exp))
        {
            TextBox44.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox44.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only numbers for Class XII marks in Percentage.\\n";
        }
    }

    public string CheckXIIdiv()
    {
        string TP = DropDownList6.SelectedValue;
        if (TP == "")
        {
            DropDownList6.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter Class XII Division.\\n";

        }
        else
        {
            DropDownList6.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
    }

    public string CheckGss()
    {
        string TN = TextBox46.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            TextBox46.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter your Graduation Subject Studied.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox46.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox46.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for Graduation Subject Studied.\\n";
        }
    }

    public string CheckGbu()
    {
        string TN = TextBox47.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            TextBox47.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter your Graduation Board/University.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox47.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox47.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for Graduation Board/University.\\n";
        }
    }


    public string CheckGmks()
    {
        string TN = TextBox48.Text.ToString();

        var exp = "[+]?([0-9]*[.])?[0-9]+";
        if (TN == "")
        {
            TextBox48.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter your Graduation marks in Percentage.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, exp))
        {
            TextBox48.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox48.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only numbers for Graduation marks in Percentage.\\n";
        }
    }

    public string CheckGdiv()
    {
        string TP = DropDownList7.SelectedValue;
        if (TP == "")
        {
            DropDownList7.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter Graduation Division.\\n";

        }
        else
        {
            DropDownList7.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
    }


    public string CheckPGss()
    {
        string TN = TextBox50.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            TextBox50.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter your Post-Graduation Subject Studied.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox50.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox50.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for Post-Graduation Subject Studied.\\n";
        }
    }

    public string CheckPGbu()
    {
        string TN = TextBox51.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            TextBox51.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter your Post-Graduation Board/University.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox51.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox51.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for Post-Graduation Board/University.\\n";
        }
    }


    public string CheckPGmks()
    {
        string TN = TextBox52.Text.ToString();

        var exp = "[+]?([0-9]*[.])?[0-9]+";
        if (TN == "")
        {
            TextBox52.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter your Post-Graduation marks in Percentage.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, exp))
        {
            TextBox52.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox52.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only numbers for Post-Graduation marks in Percentage.\\n";
        }
    }


    

    public string CheckPGdiv()
    {
        string TP = DropDownList8.SelectedValue;
        if (TP == "")
        {
            DropDownList8.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter Post-Graduation Division.\\n";

        }
        else
        {
            DropDownList8.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
    }

    public string CheckBss()
    {
        string TN = TextBox54.Text.ToString();
        if (TN == "")
        {
            TextBox54.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";

        }

        //var exp = "[a - zA - Z]";
       else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox54.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox54.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for BEd Subject Studied.\\n";
        }
    }

    public string CheckBbu()
    {
        string TN = TextBox55.Text.ToString();
        if (TN == "")
        {
            TextBox55.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";

        }
        //var exp = "[a - zA - Z]";
       else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox55.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox55.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for BEd Board/University.\\n";
        }
    }


    public string CheckBmks()
    {
        string TN = TextBox56.Text.ToString();

        var exp = "[+]?([0-9]*[.])?[0-9]+";
        if (TN == "")
        {
            TextBox56.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";

        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, exp))
        {
            TextBox56.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox56.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only numbers for BEd marks in Percentage.\\n";
        }
    }

    public string CheckMss()
    {
        string TN = TextBox58.Text.ToString();
        if (TN == "")
        {
            TextBox58.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";

        }
        //var exp = "[a - zA - Z]";
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox58.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox58.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for MEd Subject Studied.\\n";
        }
    }

    public string CheckMbu()
    {
        string TN = TextBox59.Text.ToString();
        if (TN == "")
        {
            TextBox59.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";

        }
        //var exp = "[a - zA - Z]";
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox59.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox59.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for MEd Board/University.\\n";
        }
    }


    public string CheckMmks()
    {
        string TN = TextBox60.Text.ToString();
        
        var exp = "[+]?([0-9]*[.])?[0-9]+";
        if (TN == "")
        {
            TextBox60.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";

        }
       else if (System.Text.RegularExpressions.Regex.IsMatch(TN, exp))
        {
            TextBox60.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox60.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only numbers for MEd marks in Percentage.\\n";
        }
    }

    public string CheckOss()
    {
        string TN = TextBox66.Text.ToString();
        if (TN == "")
        {
            TextBox66.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";

        }
        //var exp = "[a - zA - Z]";
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox66.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox66.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for Other Subject Studied.\\n";
        }
    }

    public string CheckObu()
    {
        string TN = TextBox67.Text.ToString();
        if (TN == "")
        {
            TextBox67.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";

        }

        //var exp = "[a - zA - Z]";
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z.,\s]+$"))
        {
            TextBox67.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox67.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only alphabets for Other Board/University.\\n";
        }
    }


    public string CheckOmks()
    {
        string TN = TextBox68.Text.ToString();

        var exp = "[+]?([0-9]*[.])?[0-9]+";
        if (TN == "")
        {
            TextBox68.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";

        }
       else if (System.Text.RegularExpressions.Regex.IsMatch(TN, exp))
        {
            TextBox68.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            return "";
        }
        else
        {
            TextBox68.BackColor = System.Drawing.ColorTranslator.FromHtml("#F78181");
            return "Please enter only numbers for Other marks in Percentage.\\n";
        }
    }

    public string CheckAoc()
    {
        string TN = TextBox62.Text.ToString();

        //var exp = "[a - zA - Z]";
        if (TN == "")
        {
            Label9.Text = "Please enter your Address of Correspondence.";
            return "Please enter your Address of Correspondence.\\n";
        }
        else if (System.Text.RegularExpressions.Regex.IsMatch(TN, @"^[a-zA-Z0-9.,\s-]+$"))
        {
            Label9.Text = "";
            return "";
        }
        else
        {
            Label9.Text = "Only alphabets, numbers and .,- are allowed for your Address of Correspondence.";
            return "Only alphabets, numbers and .,- are allowed for your Address of Correspondence.\\n";
        }
    }

    //public bool FormatChecker(HttpPostedFile n, System.Web.UI.WebControls.FileUpload FU)
    //{
    //    bool isExecutableFile = FU.FileBytes.Length > 1 &&
    //                        FU.FileBytes[0] == 0x4D &&
    //                        FU.FileBytes[1] == 0x5A;
    //    bool isMSOfficefile = FU.FileBytes.Length > 1 &&
    //                        FU.FileBytes[0] == 0x50 &&
    //                        FU.FileBytes[1] == 0x4B;
    //    if ((!isExecutableFile) && (!isMSOfficefile))
    //        return false;
    //    //else if (!isMSOfficefile)
    //    //    return false;

    //    else return true;

    //}

    public bool imageChecker(HttpPostedFile n)
    {
      
        byte[] document = new byte[n.ContentLength];
        n.InputStream.Read(document, 0, n.ContentLength);
        System.UInt32 mimetype;
        FindMimeFromData(0, null, document, 256, null, 0, out mimetype, 0);
        System.IntPtr mimeTypePtr = new IntPtr(mimetype);
        string mime = Marshal.PtrToStringUni(mimeTypePtr);
        Marshal.FreeCoTaskMem(mimeTypePtr);

        if (mime == "image/jpeg" || mime == "image/pjpeg" || mime == "image/png" || mime == "image/bmp")
        {
            return true;
        }
        else
        {
            return false;

        }
    }

    public bool PDFChecker(HttpPostedFile n)
    {

        byte[] document = new byte[n.ContentLength];
        n.InputStream.Read(document, 0, n.ContentLength);
        System.UInt32 mimetype;
        FindMimeFromData(0, null, document, 256, null, 0, out mimetype, 0);
        System.IntPtr mimeTypePtr = new IntPtr(mimetype);
        string mime = Marshal.PtrToStringUni(mimeTypePtr);
        Marshal.FreeCoTaskMem(mimeTypePtr);

        if (mime == "application/pdf")
        {
            return true;
        }
        else
        {
            return false;

        }
    }


    public string CheckPhoto()
    {
        string filename = FileUpload1.FileName;
        int count = filename.Count(f => f == '.');
        if (filename == "")
        {
            Label10.Text = "No file selected for Photo.";
            return "No file selected for Photo.\\n";
        }
        
        else if(count > 1)
        {
            Label10.Text = "Invalid Photo file.";
            return "Invalid Photo File.\\n";
        }

        else if (!imageChecker(FileUpload1.PostedFile))
        {
            Label10.Text = "Invalid file uploaded for Photo. Only jpg, png, bmp are allowed.";
            return "Invalid file uploaded for Photo. Only jpg, png, bmp are allowed.\\n";
        }
        else if (FileUpload1.PostedFile.ContentLength > 100000)
        {
            Label10.Text = "File Size is too big.Use images under 100KB. ";
            return "File Size is too big for Photo. Use images under 100KB.\\n";
        }
        else
        {
            Label10.Text = "";
            return "";
        }
                   
    }
    

    public string CheckSign()
    {
        string filename = FileUpload2.FileName;
        int count = filename.Count(f => f == '.');
        if (filename == "")
        {
            Label11.Text = "No file selected for Sign.";
            return "No file selected for Sign.\\n";
        }
        else if (count > 1)
        {
            Label11.Text = "Invalid Sign file.";
            return "Invalid Sign File.\\n";
        }
        else if (!imageChecker(FileUpload2.PostedFile))
        {
            Label11.Text = "Invalid file uploaded for Sign. Only jpg, png, bmp are allowed.";
            return "Invalid file uploaded for Sign. Only jpg, png, bmp are allowed.\\n";
        }
        else if (FileUpload2.PostedFile.ContentLength > 100000)
        {
            Label11.Text = "File Size is too big.Use images under 100KB.";
            return "File Size is too big for Sign.Use images under 100KB.\\n";
        }
        else
        {
            Label11.Text = "";
            return "";
        }
            
           
        
    }

    public string CheckRec()
    {
        string filename = FileUpload3.FileName;
        int count = filename.Count(f => f == '.');
        if (filename == "")
        {
            Label12.Text = "No file selected for Recommendation.";
            return "No file selected for Recommendation.\\n";
        }
        else if (count > 1)
        {
            Label12.Text = "Invalid Recommendation file.";
            return "Invalid Recommendation File.\\n";
        }
        else if (!PDFChecker(FileUpload3.PostedFile))
        {
            Label12.Text = "Invalid file uploaded for Recommendation. Only pdf is allowed.";
            return "Invalid file uploaded for Recommendation. Only pdf is allowed.\\n";
        }
        else if (FileUpload3.PostedFile.ContentLength > 1000000)
        {
            Label12.Text = "File Size is too big.Use pdf files under 1MB.";
            return "File Size is too big for Recommendation.Use pdf files under 1MB.\\n";
        }
        else
        {
            Label12.Text = "";
            return "";
        }
            
            
        
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        

    }

    
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox63_TextChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox64_TextChanged1(object sender, EventArgs e)
    {

    }

    protected void DropDownList8_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
       
    }

    protected void TextBox67_TextChanged(object sender, EventArgs e)
    {

    }

  
}









       


 


    


