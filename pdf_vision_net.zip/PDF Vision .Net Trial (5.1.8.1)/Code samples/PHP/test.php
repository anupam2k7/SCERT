<?php
    $v = new COM("SautinSoft.PdfVision");

	$urlPath = 'http://nationalzoo.si.edu/';
	$pdfPath = 'd:\\Document.pdf';

    /* Convert URL to PDF file */
    $result = $v->ConvertHtmlFileToPDFFile($urlPath, $pdfPath);

    if ($result==0)
	{
		//Show PDF in browser
		$filename = 'Result.pdf'; /* Note: Always use .pdf at the end. */
		header('Content-type: application/pdf');
		header('Content-Disposition: inline; filename="' . $filename . '"');
		header('Content-Transfer-Encoding: binary');
		header('Content-Length: ' . filesize($pdfPath));
		header('Accept-Ranges: bytes');
		@readfile($pdfPath);
	}    
    else
	{
		print("Converting failed!");
	}
?>