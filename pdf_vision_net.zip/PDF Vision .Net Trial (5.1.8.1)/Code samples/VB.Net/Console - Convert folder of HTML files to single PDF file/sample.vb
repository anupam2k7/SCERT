Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Convert folder of HTML files to single PDF file
            Dim v As New SautinSoft.PdfVision()

            ' Set "Edge mode" to support all modern CSS.
            SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry()

            v.PageStyle.PageOrientation.Portrait()
            v.PageStyle.PageSize.Letter()
            v.PageStyle.PageMarginLeft.Mm(20)
            v.PageStyle.PageMarginBottom.Mm(20)
            v.PageStyle.PageMarginTop.Mm(15)

            Dim directoryWithHTMLs As String = Path.GetFullPath("..\..\..\..\..\Testing Files\")
            Dim singlePdf As String = Path.Combine(directoryWithHTMLs, "Big.pdf")

            ' Convert each HTML file from directory to a PDF file.
            Dim htmlFiles() As String = Directory.GetFiles(directoryWithHTMLs, "*.htm*")
            Dim pdfInventory As New List(Of Byte())()

            For Each htmlFile As String In htmlFiles
                pdfInventory.Add(v.ConvertHtmlFileToPDFStream(htmlFile))
            Next htmlFile

            ' Merge all PDFs into a single PDF file.
            Try
                File.WriteAllBytes(singlePdf, v.MergePDFStreamArrayToPDFStream(pdfInventory))
                System.Diagnostics.Process.Start(singlePdf)
            Catch ex As Exception
                Console.WriteLine(ex.Message)
                Console.ReadLine()
            End Try
        End Sub
    End Class
End Namespace
