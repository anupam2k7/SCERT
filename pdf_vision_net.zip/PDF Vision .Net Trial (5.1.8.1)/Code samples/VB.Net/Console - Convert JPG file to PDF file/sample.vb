Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Convert JPG file to PDF file			 
            Dim v As New SautinSoft.PdfVision()
            'v.Serial = "XXXXXXXXXXXXXXX";

            'specify converting options
            v.PageStyle.PageSize.Auto()
            'v.PageStyle.PageMarginLeft.Inch(1);
            'v.ImageStyle.Heightmm(150);
            'v.ImageStyle.WidthInch(10);

            v.ImageStyle.JPEGQuality = 90

            Dim jpgFile As String = Path.GetFullPath("..\..\..\..\..\Testing Files\image1.jpg")
            Dim pdfFile As String = Path.ChangeExtension(jpgFile, ".pdf")

            'Convert image file to pdf file
            Dim ret As Integer = v.ConvertImageFileToPDFFile(jpgFile, pdfFile)

            ' 0 - converting successfully
            ' 1 - can't open input file, check the input path
            ' 2 - can't create output file, check the output path
            ' 3 - converting failed
            If ret = 0 Then
                ' Open produced PDF in default PDF Reader.
                System.Diagnostics.Process.Start(pdfFile)
            End If
        End Sub
    End Class
End Namespace
