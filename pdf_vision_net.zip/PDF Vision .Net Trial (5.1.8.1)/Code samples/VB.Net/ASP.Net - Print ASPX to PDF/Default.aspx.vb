Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.IO
Imports System.Net
Imports System.Text

Partial Public Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
        Dim id As String = Request.QueryString("id")
        Dim hd As HouseDescription = Nothing

        If id IsNot Nothing Then
            ' Recreate the page state
            hd = CType(Application(id), HouseDescription)
            SetPageState(hd)
            ' First time loading. Set all to default.
        Else
            If Not IsPostBack Then
                SetPageState(New HouseDescription())
            End If
        End If
    End Sub
    Protected Sub GetPDF_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' 1. Save the current page state
        ' 1.1. Create ID
        Dim id As String = Guid.NewGuid().ToString()

        ' 1.2 Save the current state in the Application State.
        Dim hd As HouseDescription = GetPageState()
        Application(id) = hd

        ' 2. Create url
        Dim pageUrl As String = System.Web.HttpContext.Current.Request.Url.AbsoluteUri
        Dim pageUrlWithQuerry As String = String.Format("{0}?id={1}", pageUrl, id)

        ' 3. Get PDF
        Dim v As New SautinSoft.PdfVision()

        ' Set "Edge mode" to support all modern CSS.
        SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry()
        Dim pdf() As Byte = v.ConvertHtmlFileToPDFStream(pageUrlWithQuerry)

        ' 4. Show PDF result
        If pdf IsNot Nothing Then
            Response.Buffer = True
            Response.Clear()
            Response.ContentType = "application/PDF"
            'Response.AddHeader("Content-Disposition:", "attachment; filename=Result.pdf");
            Response.AddHeader("Content-Disposition:", "inline; filename=Result.pdf")
            Response.BinaryWrite(pdf)
            Response.Flush()
            Response.End()
        End If
    End Sub
    Protected Sub SetPageState(ByVal hd As HouseDescription)
        txtHouseSpace.Text = hd.HouseSpace.ToString()
        lstFloorsNum.SelectedValue = hd.FloorsNumber.ToString()
        chkBathroom.Checked = hd.IsBathroom
        chkToilet.Checked = hd.IsToilet
        chkSwimmingPool.Checked = hd.IsSwimmingPool
    End Sub
    Protected Function GetPageState() As HouseDescription
        Dim hd As New HouseDescription()

        Dim houseSpace As Single = 0.0F

        If Single.TryParse(txtHouseSpace.Text, houseSpace) Then
            hd.HouseSpace = houseSpace
        End If

        Dim floorsNum As Integer = 1
        If Int32.TryParse(lstFloorsNum.SelectedValue, floorsNum) Then
            hd.FloorsNumber = floorsNum
        End If

        hd.IsBathroom = chkBathroom.Checked
        hd.IsToilet = chkToilet.Checked
        hd.IsSwimmingPool = chkSwimmingPool.Checked
        Return hd
    End Function
End Class
