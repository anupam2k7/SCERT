Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            'Convert multipage TIFF file to PDF file
            Dim v As New SautinSoft.PdfVision()
            'v.Serial = "XXXXXXXXXXXXXXX";

            'specify converting options
            v.PageStyle.PageSize.Auto()
            'v.PageStyle.PageMarginLeft.Inch(1);
            'v.ImageStyle.Heightmm(150);
            'v.ImageStyle.WidthInch(10);

            ' Specify a path to a TIFF file, e.g. "c:\my Funny Picture.tiff"
            Dim tiffPath As String = Path.GetFullPath("..\..\..\..\..\Testing Files\pic1.tiff")
            Dim pdfPath As String = Path.ChangeExtension(tiffPath, ".pdf")

            'Convert image file to pdf
            Dim ret As Integer = v.ConvertImageFileToPDFFile(tiffPath, pdfPath)

            '0 - converting successfully
            '1 - can't open input file, check the input path
            '2 - can't create output file, check the output path
            '3 - converting failed

            If ret = 0 Then
                ' Openf produced PDF in default PDF Viewer.
                System.Diagnostics.Process.Start(pdfPath)
            End If
        End Sub
    End Class
End Namespace
