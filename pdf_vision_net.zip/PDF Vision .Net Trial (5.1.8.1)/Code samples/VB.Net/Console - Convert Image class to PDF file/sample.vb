Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Convert Image class to PDF file			
            Dim v As New SautinSoft.PdfVision()

            'v.Serial = "XXXXXXXXXXXXXXX";

            'specify converting options
            v.PageStyle.PageSize.Auto()
            'v.PageStyle.PageMarginLeft.Inch(1);
            'v.ImageStyle.Heightmm(150);
            'v.ImageStyle.WidthInch(10);

            ' Create object of Image class from file
            Dim img As System.Drawing.Image = Image.FromFile("..\..\..\..\..\Testing Files\image1.jpg")
            Dim pdfFile As New FileInfo("copy.pdf")

            Dim imgBytes() As Byte = Nothing

            Using ms As MemoryStream = New System.IO.MemoryStream()
                img.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg)
                imgBytes = ms.ToArray()
            End Using

            'Convert image stream to PDF file
            Dim ret As Integer = v.ConvertImageStreamToPDFFile(imgBytes, pdfFile.FullName)
            If ret = 0 Then
                ' Open produced PDF in default PDF Viewer.
                System.Diagnostics.Process.Start(pdfFile.FullName)
            End If
        End Sub
    End Class
End Namespace
