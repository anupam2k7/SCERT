Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Activate the component after purchasing
            Dim v As New SautinSoft.PdfVision()

            ' Place your activation key here. You can find your "Activation Key" in email with your order.
            ' If you have any questions, email us to sales@sautinsoft.com or ask at online chat http://www.sautinsoft.com.

            ' For example:
            v.Serial = "1234567890"

            Dim imageFile As String = Path.GetFullPath("..\..\..\..\..\Testing Files\image4.jpg")
            Dim pdfFile As String = Path.ChangeExtension(imageFile, ".pdf")

            Dim ret As Integer = v.ConvertImageFileToPDFFile(imageFile, pdfFile)

            If ret = 0 Then
                ' Open produced PDF in the default PDF Reader.
                System.Diagnostics.Process.Start(pdfFile)
            End If

        End Sub
    End Class
End Namespace
