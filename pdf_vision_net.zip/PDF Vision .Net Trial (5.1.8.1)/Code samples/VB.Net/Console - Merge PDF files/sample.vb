Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Merge PDF files		
            Dim v As New SautinSoft.PdfVision()
            'v.Serial = "XXXXXXXXXXXXXXX";

            'merge 4 PDF files
            Dim files(3) As String
            files(0) = "c:\document1.pdf"
            files(1) = "c:\document2.pdf"
            files(2) = "c:\document3.pdf"
            files(3) = "c:\document4.pdf"

            Dim ret As Integer = v.MergePDFFileArrayToPDFFile(files, "c:\hardcopy.pdf")

            '0 - merged successfully
            '1 - error, can't merge PDF documents
            '2 - error, can't create output file, probably it used by another application
            '3 - merging failed
            '4 - merged successfully, but some files were not merged
            If ret = 0 Then
                System.Diagnostics.Process.Start("c:\hardcopy.pdf")
            End If
        End Sub
    End Class
End Namespace
