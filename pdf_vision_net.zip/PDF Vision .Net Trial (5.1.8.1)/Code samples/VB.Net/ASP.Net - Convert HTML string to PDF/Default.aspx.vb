Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.IO

Partial Public Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)

    End Sub
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim v As New SautinSoft.PdfVision()

        ' Set "Edge mode" to support all modern CSS.
        SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry()


        'Specify top and bottom page margins
        v.PageStyle.PageMarginTop.Mm(5.0F)
        v.PageStyle.PageMarginBottom.Mm(5.0F)

        v.PageStyle.PageSize.A4()

        'Be sure that your HTML string has full paths to images and *.css
        'Correct: <img src="http://www.mysite.com/image1.jpg">
        'Incorrect: <img src="../images/image1.jpg">

        Dim html As String = ReadFileString(Path.Combine(Server.MapPath(""), "test.htm"))

        Dim pdfBytes() As Byte = Nothing


        'convert html string to pdf stream
        pdfBytes = v.ConvertHtmlStringToPDFStream(html)


        'show PDF
        If pdfBytes IsNot Nothing Then
            Response.Buffer = True
            Response.Clear()
            Response.ContentType = "application/PDF"
            'Response.AddHeader("Content-Disposition:", "attachment; filename=Result.pdf");
            Response.AddHeader("Content-Disposition:", "inline; filename=Result.pdf")
            Response.BinaryWrite(pdfBytes)
            Response.Flush()
            Response.End()
        End If
    End Sub
    Public Shared Function ReadFileString(ByVal path As String) As String
        Using reader As New StreamReader(path)
            Return reader.ReadToEnd()
        End Using

    End Function

End Class
