Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Console - Convert HTML file to one-page PDF file.
            Dim v As New SautinSoft.PdfVision()

            ' Set "Edge mode" to support all modern CSS.
            SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry()

            v.PageStyle.PageOrientation.Portrait()

            Dim htmlPath As String = "http://nationalzoo.si.edu"
            Dim pdfPath As New FileInfo("result.pdf")

            Dim image() As Byte = v.ConvertHtmlFileToImageStream(htmlPath, SautinSoft.PdfVision.eImageFormat.Png)
            Dim ret As Integer = -1

            If image IsNot Nothing Then
                v.PageStyle.PageSize.Auto()
                ret = v.ConvertImageStreamToPDFFile(image, pdfPath.FullName)
            End If

            ' 0 - converting successfully
            ' 1 - can't open input file, check the input path
            ' 2 - can't create output file, check the output path
            ' 3 - converting failed
            If ret = 0 Then
                ' Open produced PDF in default PDF Reader.
                System.Diagnostics.Process.Start(pdfPath.FullName)
            End If
        End Sub
    End Class
End Namespace
