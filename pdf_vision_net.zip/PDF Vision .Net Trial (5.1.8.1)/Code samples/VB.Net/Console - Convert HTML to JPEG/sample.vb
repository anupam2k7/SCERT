Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Convert HTML to JPEG
            Dim v As New SautinSoft.PdfVision()

            ' Set "Edge mode" to support all modern CSS.
            SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry()

            v.PageStyle.PageOrientation.Portrait()

            Dim htmlPath As String = "http://nationalzoo.si.edu"
            Dim jpegFile As New FileInfo("result.jpg")

            v.ImageStyle.JPEGQuality = 95
            Dim ret As Integer = v.ConvertHtmlFileToImageFile(htmlPath, jpegFile.FullName, SautinSoft.PdfVision.eImageFormat.Jpeg)

            ' 0 - converting successfully
            ' 1 - can't open input file, check the input path
            ' 2 - can't create output file, check the output path
            ' 3 - converting failed
            If ret = 0 Then
                ' Open produced JPEG in default Viewer.
                System.Diagnostics.Process.Start(jpegFile.FullName)
            End If
        End Sub
    End Class
End Namespace
