Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Convert many TIFF files to PDF files in the same folder.
            Dim v As New SautinSoft.PdfVision()

            Dim tiffDir As New DirectoryInfo("..\..\..\..\..\Testing Files\")
            Dim tiffFiles() As FileInfo = tiffDir.GetFiles("*.tif*")

            For Each tiffFile As FileInfo In tiffFiles
                Dim pdfFile As String = Path.ChangeExtension(tiffFile.FullName, ".pdf")
                v.ConvertImageFileToPDFFile(tiffFile.FullName, pdfFile)
            Next tiffFile
            ' Open the folder with PDF.
            System.Diagnostics.Process.Start(tiffDir.FullName)
        End Sub
    End Class
End Namespace
