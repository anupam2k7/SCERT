Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Convert HTML string to PDF bytes.
            Dim v As New SautinSoft.PdfVision()

            'v.Serial = "XXXXXXXXXXXXXXX";

            ' Set "Edge mode" to support all modern CSS.
            SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry()

            'specify converting options
            v.PageStyle.PageSize.Auto()
            'v.PageStyle.PageMarginLeft.Inch(1);
            'v.ImageStyle.Heightmm(150);
            'v.ImageStyle.WidthInch(10);

            'Specify top and bottom page margins
            v.PageStyle.PageMarginTop.Mm(5.0F)
            v.PageStyle.PageMarginBottom.Mm(5.0F)

            Dim html As String = "<html><body><p style=""text-align: center; font-size: 45px;"">Hello my Friend!</p></body></html>"

            ' Convert HTML string to PDF bytes.
            Dim pdf() As Byte = v.ConvertHtmlStringToPDFStream(html)

            ' Save PDF data to a file and open it for demonstration purposes.
            If pdf IsNot Nothing Then

                Dim pdfFile As New FileInfo("Result.pdf")

                Using fs As New FileStream(pdfFile.FullName, FileMode.Create, FileAccess.Write)
                    fs.Write(pdf, 0, pdf.Length)
                End Using
                System.Diagnostics.Process.Start(pdfFile.FullName)
            End If
        End Sub
    End Class
End Namespace
