Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Convert HTML file/url to PDF file
            Dim v As New SautinSoft.PdfVision()

            ' Set "Edge mode" to support all modern CSS.
            SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry()

            'v.Serial = "XXXXXXXXXXXXXXX";
            Dim pdfFile As New FileInfo("copy.pdf")

            Dim ret As Integer = v.ConvertHtmlFileToPDFFile("http://www.sautinsoft.com/products/pdf-vision/index.php", pdfFile.FullName)

            ' 0 - converting successfully
            ' 1 - can't open input file, check the input path
            ' 2 - can't create output file, check the output path
            ' 3 - converting failed
            If ret = 0 Then
                ' Opend produced PDF in default PDF viewer.
                System.Diagnostics.Process.Start(pdfFile.FullName)
            End If
        End Sub
    End Class
End Namespace
