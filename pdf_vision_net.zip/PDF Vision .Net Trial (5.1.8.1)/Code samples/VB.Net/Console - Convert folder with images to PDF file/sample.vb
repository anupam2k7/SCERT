Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Convert folder with images to PDF files
            Dim v As New SautinSoft.PdfVision()
            'v.Serial = "XXXXXXXXXXXXXXX";

            ' Set some options.
            v.PageStyle.PageSize.Auto()
            'v.PageStyle.PageMarginLeft.Inch(1);
            'v.ImageStyle.Heightmm(150);
            'v.ImageStyle.WidthInch(10);

            v.ImageStyle.JPEGQuality = 80 '50-100
            v.ImageStyle.FitImageToPageSize = False

            ' Specify directory with images. Any local path, like a: "c:\images\".
            Dim directoryWithImages As String = Path.GetFullPath("..\..\..\..\..\Testing Files\")
            Dim pdfFile As String = Path.Combine(directoryWithImages, "Single.pdf")


            ' Convert all image files from directory to PDF file
            ' Image files: *.jpg, *.bmp, *.gif, *.tiff, *.tif, *.png, *.ico, *.emf, *.exif, *.jpeg, *.jpe, *.jfif, *.photocd, *.flashpix.
            Dim ret As Integer = v.ConvertImageFolderToPDFFile(directoryWithImages, pdfFile)

            '0 - converting successfully
            '1 - directory doesn't contain any image file
            '2 - can't create output file, check the output path
            '3 - converting failed

            If ret = 0 Then
                ' Open produced PDF in default PDF Reader.
                System.Diagnostics.Process.Start(pdfFile)
            End If
        End Sub
    End Class
End Namespace
