Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.IO
Imports System.Drawing
Imports System.Collections

Partial Public Class _Default
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
		Result.Text = ""
	End Sub
	Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs)
		Dim v As New SautinSoft.PdfVision()

        Dim imgInventory As New List(Of Byte())()

		If FileUpload1.FileBytes.Length > 0 Then
            imgInventory.Add(FileUpload1.FileBytes)
		End If

		If FileUpload2.FileBytes.Length > 0 Then
            imgInventory.Add(FileUpload2.FileBytes)
		End If

		If FileUpload3.FileBytes.Length > 0 Then
            imgInventory.Add(FileUpload3.FileBytes)
		End If

		If FileUpload4.FileBytes.Length > 0 Then
            imgInventory.Add(FileUpload4.FileBytes)
		End If

		'convert arraylist with image streams to pdf stream
        Dim pdfBytes() As Byte = v.ConvertImageStreamArrayToPDFStream(imgInventory)


		'show PDF
		If pdfBytes IsNot Nothing Then
			Response.Buffer = True
			Response.Clear()
			Response.ContentType = "application/PDF"
			'Response.AddHeader("Content-Disposition:", "attachment; filename=Result.pdf");
			Response.AddHeader("Content-Disposition:", "inline; filename=Result.pdf")
			Response.BinaryWrite(pdfBytes)
			Response.Flush()
			Response.End()
		Else
			Result.Text = "Converting failed!"
		End If
	End Sub
End Class
