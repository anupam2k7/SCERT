Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            'Convert HTML file/url to PDF file
            Dim v As New SautinSoft.PdfVision()
            'v.Serial = "XXXXXXXXXXXXXXX";

            'specify converting options
            v.PageStyle.PageSize.Auto()
            'v.PageStyle.PageMarginLeft.Inch(1);
            'v.ImageStyle.Heightmm(150);
            'v.ImageStyle.WidthInch(10);

            'Specify top and bottom page margins
            'v.PageStyle.PageMarginTop.Mm(5f);
            'v.PageStyle.PageMarginBottom.Mm(5f);

            SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry()

            'Convert image file to pdf file
            Dim pdfFile As New FileInfo("copy.pdf")

            Dim ret As Integer = v.ConvertHtmlFileToPDFFile("http://nationalzoo.si.edu/", pdfFile.FullName)

            ' 0 - converting successfully
            ' 1 - can't open input file, check the input path
            ' 2 - can't create output file, check the output path
            ' 3 - converting failed
            If ret = 0 Then
                'Show produced pdf in Acrobat Reader
                System.Diagnostics.Process.Start(pdfFile.FullName)
            End If
        End Sub
    End Class
End Namespace
