Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            'Merge PDF in memory
            Dim v As New SautinSoft.PdfVision()
            'v.Serial = "XXXXXXXXXXXXXXX";

            'merge 4 PDF files
            Dim pdfFilesArr(3) As String
            pdfFilesArr(0) = "c:\document1.pdf"
            pdfFilesArr(1) = "c:\document2.pdf"
            pdfFilesArr(2) = "c:\document3.pdf"
            pdfFilesArr(3) = "c:\document4.pdf"

            Dim singlePdf As New FileInfo("single.pdf")

            Dim pdfInventory As New List(Of Byte())()

            ' Fill the pdfBytesList.
            For Each pdfFile As String In pdfFilesArr
                pdfInventory.Add(File.ReadAllBytes(pdfFile))
            Next pdfFile

            Dim pdfBytes() As Byte = v.MergePDFStreamArrayToPDFStream(pdfInventory)

            If pdfBytes IsNot Nothing Then
                File.WriteAllBytes(singlePdf.FullName, pdfBytes)
                System.Diagnostics.Process.Start(singlePdf.FullName)
            End If
        End Sub
    End Class
End Namespace
