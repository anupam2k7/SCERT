Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Split PDF document			
            Dim v As New SautinSoft.PdfVision()
            'v.Serial = "XXXXXXXXXXXXXXX";

            '  Split PDF document by pages
            Dim ret As Integer = v.SplitPDFFileToPDFFolder("c:\source.pdf", "c:\")

            '0 - split successfully
            '1 - error, can't open input file
            '2 - error, output directory doesn't exist

            If ret = 0 Then
                System.Console.WriteLine("Split successfully!")
            End If
        End Sub
    End Class
End Namespace
