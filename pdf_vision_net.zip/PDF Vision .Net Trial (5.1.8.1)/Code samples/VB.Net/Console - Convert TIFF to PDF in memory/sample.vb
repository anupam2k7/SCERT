Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Convert TIFF to PDF in memory			
            Dim v As New SautinSoft.PdfVision()
            'v.Serial = "XXXXXXXXXXXXXXX";

            'specify converting options
            v.PageStyle.PageSize.Auto()
            'v.PageStyle.PageMarginLeft.Inch(1);
            'v.ImageStyle.Heightmm(150);
            'v.ImageStyle.WidthInch(10);

            ' Specify a path to a TIFF file, e.g. "c:\my Funny Picture.tiff"
            Dim tiffPath As String = Path.GetFullPath("..\..\..\..\..\Testing Files\pic1.tiff")
            Dim pdfPath As String = Path.ChangeExtension(tiffPath, ".pdf")

            '1. Read bytes from TIFF
            Dim imageBytes() As Byte = File.ReadAllBytes(tiffPath)

            '2. Convert TIFF bytes to PDF bytes			
            Dim pdf() As Byte = v.ConvertImageStreamToPdfStream(imageBytes)

            '3. Save PDF bytes to file
            If pdf IsNot Nothing Then
                File.WriteAllBytes(pdfPath, pdf)
                System.Diagnostics.Process.Start(pdfPath)
            End If
        End Sub
    End Class
End Namespace
