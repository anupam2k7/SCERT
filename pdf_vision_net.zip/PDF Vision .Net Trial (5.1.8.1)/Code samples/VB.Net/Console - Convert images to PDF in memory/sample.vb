Imports System.IO

Namespace Sample
    Friend Class Test

        Shared Sub Main(ByVal args() As String)
            ' Convert images to PDF in memory			 			
            Dim v As New SautinSoft.PdfVision()
            'v.Serial = "XXXXXXXXXXXXXXX";

            'specify converting options
            v.PageStyle.PageSize.Auto()
            'v.PageStyle.PageMarginLeft.Inch(1);
            'v.ImageStyle.Heightmm(150);
            'v.ImageStyle.WidthInch(10);			

            'Create array containing paths to different images
            Dim imgFiles() As String = {"..\..\..\..\..\Testing Files\image1.jpg", "..\..\..\..\..\Testing Files\image2.png", "..\..\..\..\..\Testing Files\image3.gif", "..\..\..\..\..\Testing Files\image4.jpg"}

            Dim imgBytesList As New List(Of Byte())()

            For Each imgFile As String In imgFiles
                imgBytesList.Add(File.ReadAllBytes(imgFile))
            Next imgFile

            ' Convert list with image bytes to PDF bytes.
            Dim pdfBytes() As Byte = v.ConvertImageStreamArrayToPDFStream(imgBytesList)
            If pdfBytes IsNot Nothing Then
                ' Save PDF stream to a file.
                Dim pdfFile As New FileInfo("copy.pdf")
                File.WriteAllBytes(pdfFile.FullName, pdfBytes)

                ' Open produced PDF in default PDF Reader.
                System.Diagnostics.Process.Start(pdfFile.FullName)
            End If
        End Sub
    End Class
End Namespace
