using System;
using System.IO;
using System.Collections.Generic;

namespace Sample
{
    class Test
    {

        static void Main(string[] args)
        {

            //Merge PDF in memory
            SautinSoft.PdfVision v = new SautinSoft.PdfVision();
            //v.Serial = "XXXXXXXXXXXXXXX";

            //merge 4 PDF files
            string[] pdfFilesArr = new string[4];
            pdfFilesArr[0] = @"c:\document1.pdf";
            pdfFilesArr[1] = @"c:\document2.pdf";
            pdfFilesArr[2] = @"c:\document3.pdf";
            pdfFilesArr[3] = @"c:\document4.pdf";

            FileInfo singlePdf = new FileInfo("single.pdf");

            List<byte[]> pdfInventory = new List<byte[]>();

            // Fill the pdfBytesList.
            foreach (string pdfFile in pdfFilesArr)
                pdfInventory.Add(File.ReadAllBytes(pdfFile));

            byte[] pdfBytes = v.MergePDFStreamArrayToPDFStream(pdfInventory);

            if (pdfBytes != null)
            {
                File.WriteAllBytes(singlePdf.FullName, pdfBytes);
                System.Diagnostics.Process.Start(singlePdf.FullName);
            }
        }
    }
}
