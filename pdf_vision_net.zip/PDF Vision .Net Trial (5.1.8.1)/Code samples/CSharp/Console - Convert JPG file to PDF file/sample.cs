using System;
using System.IO;

namespace Sample
{
	class Test
	{
		
		static void Main(string[] args)
		{

			// Convert JPG file to PDF file			 
			SautinSoft.PdfVision v = new SautinSoft.PdfVision();
			//v.Serial = "XXXXXXXXXXXXXXX";
			
			//specify converting options
			v.PageStyle.PageSize.Auto();
			//v.PageStyle.PageMarginLeft.Inch(1);
			//v.ImageStyle.Heightmm(150);
			//v.ImageStyle.WidthInch(10);

			v.ImageStyle.JPEGQuality=90;

            string jpgFile = Path.GetFullPath(@"..\..\..\..\..\Testing Files\image1.jpg");
            string pdfFile = Path.ChangeExtension(jpgFile,".pdf");

			//Convert image file to pdf file
			int ret = v.ConvertImageFileToPDFFile(jpgFile, pdfFile);

			// 0 - converting successfully
			// 1 - can't open input file, check the input path
			// 2 - can't create output file, check the output path
			// 3 - converting failed
			if(ret==0 )
			{
				// Open produced PDF in default PDF Reader.
				System.Diagnostics.Process.Start(pdfFile);
			}
		}
	}
}
