using System;
using System.IO;
using System.Collections.Generic;

namespace Sample
{
	class Test
	{
		
		static void Main(string[] args)
		{
			// Convert folder with images to PDF files
			SautinSoft.PdfVision v = new SautinSoft.PdfVision();
			//v.Serial = "XXXXXXXXXXXXXXX";
			
			// Set some options.
			v.PageStyle.PageSize.Auto();
			//v.PageStyle.PageMarginLeft.Inch(1);
			//v.ImageStyle.Heightmm(150);
			//v.ImageStyle.WidthInch(10);

			v.ImageStyle.JPEGQuality=80; //50-100
            v.ImageStyle.FitImageToPageSize = false;            
		
			// Specify directory with images. Any local path, like a: "c:\images\".
			string directoryWithImages = Path.GetFullPath(@"..\..\..\..\..\Testing Files\");
            string pdfFile = Path.Combine(directoryWithImages, "Single.pdf");


			// Convert all image files from directory to PDF file
			// Image files: *.jpg, *.bmp, *.gif, *.tiff, *.tif, *.png, *.ico, *.emf, *.exif, *.jpeg, *.jpe, *.jfif, *.photocd, *.flashpix.
			int ret = v.ConvertImageFolderToPDFFile(directoryWithImages, pdfFile);
			
			//0 - converting successfully
			//1 - directory doesn't contain any image file
			//2 - can't create output file, check the output path
			//3 - converting failed
			
			if(ret==0 )
			{
				// Open produced PDF in default PDF Reader.
				System.Diagnostics.Process.Start(pdfFile);
			}
		}
	}
}
