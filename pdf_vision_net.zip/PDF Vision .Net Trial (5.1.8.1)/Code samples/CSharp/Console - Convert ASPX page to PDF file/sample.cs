using System;
using System.IO;

namespace Sample
{
    class Test
    {

        static void Main(string[] args)
        {
            // Convert ASPX page to PDF file	 
            SautinSoft.PdfVision v = new SautinSoft.PdfVision();

            // Set "Edge mode" to support all modern CSS.
            SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry();

            //v.Serial = "XXXXXXXXXXXXXXX";

            // Specify some options.
            v.PageStyle.PageSize.A4();
            v.PageStyle.PageOrientation.Landscape();
            v.PageStyle.PageNumbers.PageNumbersInBottom = "Page {page} of {numpages}";
            v.PageStyle.PageNumbers.Aligment.Center();
            v.PageStyle.PageNumbers.FontSize = 16;
            v.PageStyle.PageNumbers.FontColor.SetRGB(128, 255, 0);
            v.PageStyle.PageNumbers.MarginFromStart.Mm(30);



            //v.PageStyle.PageMarginLeft.Inch(1);
            //v.ImageStyle.Heightmm(150);
            //v.ImageStyle.WidthInch(10);

            // Convert ASPX page to PDF file.
            FileInfo pdfFile = new FileInfo("result.pdf");
            string aspxPage = @"http://www.sautinsoft.net/online-demo/pdf-vision/online-demo.aspx";
            int ret = v.ConvertHtmlFileToPDFFile(aspxPage, pdfFile.FullName);

            // 0 - converting successfully.
            // 1 - can't open input file, check the input path.
            // 2 - can't create output file, check the output path.
            // 3 - converting failed.
            if (ret == 0)
            {
                // Show produced PDF in default PDF Reader.
                System.Diagnostics.Process.Start(pdfFile.FullName);
            }
        }
    }
}
