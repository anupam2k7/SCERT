using System;
using System.IO;

namespace Sample
{
    class Test
    {

        static void Main(string[] args)
        {
            // Convert HTML to PNG
            SautinSoft.PdfVision v = new SautinSoft.PdfVision();

            // Set "Edge mode" to support all modern CSS.
            SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry();

            v.PageStyle.PageOrientation.Portrait();

            string htmlPath = @"http://nationalzoo.si.edu";
            FileInfo pngFile = new FileInfo("result.png");

            int ret = v.ConvertHtmlFileToImageFile(htmlPath, pngFile.FullName, SautinSoft.PdfVision.eImageFormat.Png);

            // 0 - converting successfully
            // 1 - can't open input file, check the input path
            // 2 - can't create output file, check the output path
            // 3 - converting failed
            if (ret == 0)
            {
                // Open produced PNG in default Viewer.
                System.Diagnostics.Process.Start(pngFile.FullName);
            }
        }
    }
}
