using System;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;

namespace Sample
{
    class Test
    {
        static void Main(string[] args)
        {
            // Convert many TIFF files to PDF files in the same folder.
            SautinSoft.PdfVision v = new SautinSoft.PdfVision();

            DirectoryInfo tiffDir = new DirectoryInfo(@"..\..\..\..\..\Testing Files\");
            FileInfo[] tiffFiles = tiffDir.GetFiles(@"*.tif*");

            foreach (FileInfo tiffFile in tiffFiles)
            {
                string pdfFile = Path.ChangeExtension(tiffFile.FullName, ".pdf");
                v.ConvertImageFileToPDFFile(tiffFile.FullName, pdfFile);
            }
            // Open the folder with PDF.
            System.Diagnostics.Process.Start(tiffDir.FullName);
        }
    }
}