using System;
using System.IO;
using System.Drawing;

namespace Sample
{
    class Test
    {
        static void Main(string[] args)
        {
            // Convert Image class to PDF file			
            SautinSoft.PdfVision v = new SautinSoft.PdfVision();

            //v.Serial = "XXXXXXXXXXXXXXX";

            //specify converting options
            v.PageStyle.PageSize.Auto();
            //v.PageStyle.PageMarginLeft.Inch(1);
            //v.ImageStyle.Heightmm(150);
            //v.ImageStyle.WidthInch(10);

            // Create object of Image class from file
            System.Drawing.Image img = Image.FromFile(@"..\..\..\..\..\Testing Files\image1.jpg");
            FileInfo pdfFile = new FileInfo(@"copy.pdf");

            byte[] imgBytes = null;

            using (MemoryStream ms = new System.IO.MemoryStream())
            {
                img.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                imgBytes = ms.ToArray();
            }

            //Convert image stream to PDF file
            int ret = v.ConvertImageStreamToPDFFile(imgBytes, pdfFile.FullName);
            if (ret == 0)
            {
                // Open produced PDF in default PDF Viewer.
                System.Diagnostics.Process.Start(pdfFile.FullName);
            }
        }
    }
}
