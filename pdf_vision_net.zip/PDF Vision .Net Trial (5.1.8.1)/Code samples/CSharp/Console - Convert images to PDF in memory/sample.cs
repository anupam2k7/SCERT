using System;
using System.IO;
using System.Collections.Generic;

namespace Sample
{
    class Test
    {

        static void Main(string[] args)
        {
            // Convert images to PDF in memory			 			
            SautinSoft.PdfVision v = new SautinSoft.PdfVision();
            //v.Serial = "XXXXXXXXXXXXXXX";

            //specify converting options
            v.PageStyle.PageSize.Auto();
            //v.PageStyle.PageMarginLeft.Inch(1);
            //v.ImageStyle.Heightmm(150);
            //v.ImageStyle.WidthInch(10);			

            //Create array containing paths to different images
            string[] imgFiles = new string[4]
            { @"..\..\..\..\..\Testing Files\image1.jpg",
              @"..\..\..\..\..\Testing Files\image2.png",
              @"..\..\..\..\..\Testing Files\image3.gif",
              @"..\..\..\..\..\Testing Files\image4.jpg"};

            List<byte[]> imgBytesList = new List<byte[]>();

            foreach (string imgFile in imgFiles)
                imgBytesList.Add(File.ReadAllBytes(imgFile));

            // Convert list with image bytes to PDF bytes.
            byte[] pdfBytes = v.ConvertImageStreamArrayToPDFStream(imgBytesList);
            if (pdfBytes != null)
            {
                // Save PDF stream to a file.
                FileInfo pdfFile = new FileInfo(@"copy.pdf");
                File.WriteAllBytes(pdfFile.FullName, pdfBytes);

                // Open produced PDF in default PDF Reader.
                System.Diagnostics.Process.Start(pdfFile.FullName);
            }
        }
    }
}
