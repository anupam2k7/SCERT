using System;
using System.IO;
using System.Collections;

namespace Sample
{
    class Test
    {

        static void Main(string[] args)
        {
            // Split PDF document			
            SautinSoft.PdfVision v = new SautinSoft.PdfVision();
            //v.Serial = "XXXXXXXXXXXXXXX";

            //  Split PDF document by pages
            int ret = v.SplitPDFFileToPDFFolder(@"c:\source.pdf", @"c:\");

            //0 - split successfully
            //1 - error, can't open input file
            //2 - error, output directory doesn't exist

            if (ret == 0)
            {
                System.Console.WriteLine("Split successfully!");
            }

        }
    }
}
