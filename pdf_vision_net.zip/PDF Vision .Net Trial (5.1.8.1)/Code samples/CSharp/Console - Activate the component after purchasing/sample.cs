using System;
using System.IO;

namespace Sample
{
    class Test
    {

        static void Main(string[] args)
        {
            // Activate the component after purchasing
            SautinSoft.PdfVision v = new SautinSoft.PdfVision();

            // Place your activation key here. You can find your "Activation Key" in email with your order.
            // If you have any questions, email us to sales@sautinsoft.com or ask at online chat http://www.sautinsoft.com.

            // For example:
            v.Serial = "1234567890";

            string imageFile = Path.GetFullPath(@"..\..\..\..\..\Testing Files\image4.jpg");
            string pdfFile = Path.ChangeExtension(imageFile, ".pdf");

            int ret = v.ConvertImageFileToPDFFile(imageFile, pdfFile);

            if (ret == 0)
            {
                // Open produced PDF in the default PDF Reader.
                System.Diagnostics.Process.Start(pdfFile);
            }
        }
    }
}
