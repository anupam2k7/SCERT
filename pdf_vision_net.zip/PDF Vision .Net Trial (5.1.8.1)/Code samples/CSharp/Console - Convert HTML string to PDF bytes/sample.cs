using System;
using System.IO;

namespace Sample
{
    class Test
    {
        static void Main(string[] args)
        {
            // Convert HTML string to PDF bytes.
            SautinSoft.PdfVision v = new SautinSoft.PdfVision();

            //v.Serial = "XXXXXXXXXXXXXXX";

            // Set "Edge mode" to support all modern CSS.
            SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry();

            //specify converting options
            v.PageStyle.PageSize.Auto();
            //v.PageStyle.PageMarginLeft.Inch(1);
            //v.ImageStyle.Heightmm(150);
            //v.ImageStyle.WidthInch(10);

            //Specify top and bottom page margins
            v.PageStyle.PageMarginTop.Mm(5f);
            v.PageStyle.PageMarginBottom.Mm(5f);

            string html = "<html><body><p style=\"text-align: center; font-size: 45px;\">Hello my Friend!</p></body></html>";

            // Convert HTML string to PDF bytes.
            byte[] pdf = v.ConvertHtmlStringToPDFStream(html);

            // Save PDF data to a file and open it for demonstration purposes.
            if (pdf != null)
            {

                FileInfo pdfFile = new FileInfo(@"Result.pdf");

                using (FileStream fs = new FileStream(pdfFile.FullName, FileMode.Create, FileAccess.Write))
                {
                    fs.Write(pdf, 0, pdf.Length);                 
                }
                System.Diagnostics.Process.Start(pdfFile.FullName);
            }
        }
    }
}
