using System;
using System.IO;
using System.Collections;


namespace Sample
{
    class Test
    {

        static void Main(string[] args)
        {
            // Convert TIFF to PDF in memory			
            SautinSoft.PdfVision v = new SautinSoft.PdfVision();
            //v.Serial = "XXXXXXXXXXXXXXX";

            //specify converting options
            v.PageStyle.PageSize.Auto();
            //v.PageStyle.PageMarginLeft.Inch(1);
            //v.ImageStyle.Heightmm(150);
            //v.ImageStyle.WidthInch(10);

            // Specify a path to a TIFF file, e.g. "c:\my Funny Picture.tiff"
            string tiffPath = Path.GetFullPath(@"..\..\..\..\..\Testing Files\pic1.tiff");
            string pdfPath = Path.ChangeExtension(tiffPath, ".pdf");

            //1. Read bytes from TIFF
            byte[] imageBytes = File.ReadAllBytes(tiffPath);

            //2. Convert TIFF bytes to PDF bytes			
            byte[] pdf = v.ConvertImageStreamToPdfStream(imageBytes);

            //3. Save PDF bytes to file
            if (pdf != null)
            {
                File.WriteAllBytes(pdfPath, pdf);
                System.Diagnostics.Process.Start(pdfPath);
            }
        }
    }
}
