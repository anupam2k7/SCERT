using System;
using System.IO;

namespace Sample
{
    class Test
    {

        static void Main(string[] args)
        {

            // Convert HTML file/url to PDF file
            SautinSoft.PdfVision v = new SautinSoft.PdfVision();

            // Set "Edge mode" to support all modern CSS.
            SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry();

            //v.Serial = "XXXXXXXXXXXXXXX";
            FileInfo pdfFile = new FileInfo("copy.pdf");

            int ret = v.ConvertHtmlFileToPDFFile(@"http://www.sautinsoft.com/products/pdf-vision/index.php", pdfFile.FullName);

            // 0 - converting successfully
            // 1 - can't open input file, check the input path
            // 2 - can't create output file, check the output path
            // 3 - converting failed
            if (ret == 0)
            {
                // Opend produced PDF in default PDF viewer.
                System.Diagnostics.Process.Start(pdfFile.FullName);
            }
        }
    }
}
