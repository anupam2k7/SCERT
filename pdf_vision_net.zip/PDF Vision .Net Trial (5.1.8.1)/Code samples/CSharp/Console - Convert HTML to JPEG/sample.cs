using System;
using System.IO;

namespace Sample
{
    class Test
    {

        static void Main(string[] args)
        {
            // Convert HTML to JPEG
            SautinSoft.PdfVision v = new SautinSoft.PdfVision();

            // Set "Edge mode" to support all modern CSS.
            SautinSoft.PdfVision.TrySetBrowserModeEdgeInRegistry();

            v.PageStyle.PageOrientation.Portrait();

            string htmlPath = @"http://nationalzoo.si.edu";
            FileInfo jpegFile = new FileInfo("result.jpg");

            v.ImageStyle.JPEGQuality = 95;
            int ret = v.ConvertHtmlFileToImageFile(htmlPath, jpegFile.FullName, SautinSoft.PdfVision.eImageFormat.Jpeg);

            // 0 - converting successfully
            // 1 - can't open input file, check the input path
            // 2 - can't create output file, check the output path
            // 3 - converting failed
            if (ret == 0)
            {
                // Open produced JPEG in default Viewer.
                System.Diagnostics.Process.Start(jpegFile.FullName);
            }
        }
    }
}
